/*** CompassRose ***/
A jQuery plugin created by Brian Muenzenmeyer
www.compassro.se

download, fork, and follow development at https://github.com/bmuenzenmeyer/CompassRose