/*** CompassRose ***/
A jQuery plugin created by Brian Muenzenmeyer
live demo @ www.compassro.se

download, fork, and follow development at https://github.com/bmuenzenmeyer/CompassRose